# CGBookV2Code
运行环境：VS 2017

需要配置OpenGL的Glut库，可以参考：https://blog.csdn.net/wpxu08/article/details/87785547